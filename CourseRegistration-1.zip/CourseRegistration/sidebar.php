<ul class="sidebar navbar-nav">
  <li class="nav-item active">
    <a class="nav-link" href="dashboard.php">
      <i class="fas fa-fw fa-tachometer-alt"></i>
      <span>Dashboard</span>
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link" href="analysis.php">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Analysis</span></a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="RegisterCourse.php">
      <i class="fas fa-fw fa-plus"></i>
      <span>Add Course</span></a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="result.php">
      <i class="fas fa-fw fa-table"></i>
      <span>Result</span></a>
  </li>
</ul>
